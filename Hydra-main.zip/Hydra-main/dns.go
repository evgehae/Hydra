package hydra

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"sync/atomic"
	"time"
)

// На Android у Go нет /etc/resolv.conf, поэтому встроенный резолвер идёт на
// localhost:53 — а там никого нет. Лечим: сами задаём DNS-серверы + полноценный DoH.

var fallbackDNS = []string{"1.1.1.1", "8.8.8.8", "9.9.9.9", "77.88.8.8"}

// dohEndpoints — публичные DoH-серверы по IP (чтобы не зависеть от системного DNS).
var dohEndpoints = []string{
	"https://1.1.1.1/dns-query",
	"https://1.0.0.1/dns-query",
	"https://8.8.8.8/dns-query",
	"https://9.9.9.9/dns-query",
	"https://149.112.112.112/dns-query", // Quad9
}

// SetSystemDNS подменяет резолвер процесса: сначала переданные серверы
// (только IP-адреса), потом запасные. Каждая новая попытка идёт на следующий сервер.
func SetSystemDNS(servers []string) {
	var list []string
	seen := map[string]bool{}
	add := func(s string) {
		s = strings.TrimSpace(s)
		if s == "" || net.ParseIP(s) == nil || seen[s] {
			return
		}
		seen[s] = true
		list = append(list, s)
	}
	for _, s := range servers {
		add(s)
	}
	for _, s := range fallbackDNS {
		add(s)
	}
	if len(list) == 0 {
		list = append(list, "1.1.1.1")
	}
	var n uint32
	net.DefaultResolver = &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, _ string) (net.Conn, error) {
			i := int(atomic.AddUint32(&n, 1)-1) % len(list)
			d := net.Dialer{Timeout: 3 * time.Second}
			return d.DialContext(ctx, network, net.JoinHostPort(list[i], "53"))
		},
	}
}

// ResolveDoH делает полноценный DNS-over-HTTPS запрос (JSON API) и возвращает IPv4.
// Не зависит от системного DNS — ходит напрямую на IP DoH-серверов.
func ResolveDoH(ctx context.Context, host string) (net.IP, error) {
	host = strings.TrimSpace(host)
	if host == "" {
		return nil, fmt.Errorf("пустое имя")
	}
	if ip := net.ParseIP(host); ip != nil {
		return ip.To4(), nil
	}

	client := &http.Client{
		Timeout: 5 * time.Second,
		Transport: &http.Transport{
			DisableKeepAlives:   true,
			TLSHandshakeTimeout: 4 * time.Second,
		},
	}

	var lastErr error
	for _, base := range dohEndpoints {
		u := base + "?name=" + host + "&type=A"
		req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
		if err != nil {
			lastErr = err
			continue
		}
		req.Header.Set("Accept", "application/dns-json")
		resp, err := client.Do(req)
		if err != nil {
			lastErr = err
			continue
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<16))
		resp.Body.Close()
		if resp.StatusCode != 200 {
			lastErr = fmt.Errorf("DoH %s: HTTP %d", base, resp.StatusCode)
			continue
		}
		var out struct {
			Answer []struct {
				Type int    `json:"type"`
				Data string `json:"data"`
			} `json:"Answer"`
		}
		if err := json.Unmarshal(body, &out); err != nil {
			lastErr = err
			continue
		}
		for _, a := range out.Answer {
			if a.Type == 1 {
				if ip := net.ParseIP(a.Data); ip != nil {
					if ip4 := ip.To4(); ip4 != nil {
						return ip4, nil
					}
				}
			}
		}
		lastErr = fmt.Errorf("DoH %s: нет A-записи", base)
	}
	if lastErr == nil {
		lastErr = fmt.Errorf("DoH: пустой ответ")
	}
	return nil, lastErr
}

// ResolveA предпочитает DoH, при неудаче падает на обычный системный резолвер.
func ResolveA(ctx context.Context, host string) (net.IP, error) {
	if ip, err := ResolveDoH(ctx, host); err == nil && ip != nil {
		return ip, nil
	}
	cctx, cancel := context.WithTimeout(ctx, 4*time.Second)
	defer cancel()
	addrs, err := net.DefaultResolver.LookupIPAddr(cctx, host)
	if err != nil {
		return nil, err
	}
	for _, a := range addrs {
		if ip4 := a.IP.To4(); ip4 != nil {
			return ip4, nil
		}
	}
	return nil, fmt.Errorf("нет IPv4 для %s", host)
}

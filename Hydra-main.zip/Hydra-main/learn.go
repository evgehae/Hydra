package hydra

import (
	"context"
	"fmt"
	"math/rand"
	"net"
	"strconv"
	"time"
)

// Самообучение: когда все известные способы подвели, Гидра придумывает новые — мутирует лучшие
// (TTL и число фейковых пакетов, их размер, SNI, адрес), запоминает и выбрасывает те, что не работают.

var fakeSNIPool = []string{"www.google.com", "vk.com", "ya.ru", "yandex.ru", "mail.ru", "www.microsoft.com", "cloudflare.com", "dzen.ru"}
var fakeSizePool = []int{64, 100, 128, 200, 256, 400, 600, 900, 1200}

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

// allStrategies — встроенные стратегии плюс придуманные для этой сети.
func (e *Engine) allStrategies(nk string) []Strategy {
	out := append([]Strategy(nil), e.cfg.Strategies...)
	for _, s := range e.cfg.Mem.Generated(nk) {
		if e.cfg.Allow == nil || e.cfg.Allow(s) { // придуманные стратегии чужого протокола не подмешиваем
			out = append(out, s)
		}
	}
	return out
}

// sniPool — SNI, которые принимает сервер MASQUE Cloudflare (сертификат проверяется по ключу, а не по имени).
var sniPool = []string{
	"consumer-masque.cloudflareclient.com", "cdnjs.cloudflare.com", "www.cloudflare.com",
	"one.one.one.one", "developers.cloudflare.com", "dash.cloudflare.com",
	"speed.cloudflare.com", "cloudflare.dev", "research.cloudflare.com",
	"www.speedtest.net", "www.microsoft.com", "www.apple.com", "www.bing.com",
	// российские сайты: имена, которые операторы пропускают даже в режиме белых списков
	"ya.ru", "yandex.ru", "dzen.ru", "vk.com", "mail.ru", "gosuslugi.ru",
}

// Порты, на которых слушают серверы WARP (взято из списков сканеров и генераторов конфигов).
var masquePorts = []string{"443", "8443", "4443", "8095", "500", "1701", "4500"}
var wgPorts = []string{"2408", "500", "1701", "4500", "854", "859", "864", "878", "880", "890", "891", "894", "903",
	"908", "928", "934", "939", "942", "943", "945", "946", "955", "968", "987", "988", "1002", "1010", "1014",
	"1018", "1070", "1074", "1180", "3476", "3581", "3854", "4177", "4198", "4233", "5279", "5956", "7103",
	"7152", "7156", "7281", "7559", "8319", "8742", "8854", "8886"}
var keepPool = []int{5, 10, 15, 30}
var keepPoolS = []string{"5", "10", "15", "30"}
var noisePool = []string{"0", "5", "10", "15"}

func family(s Strategy) string {
	switch {
	case s.Transport == "masque" && s.Params["h2"] == "1":
		return "h2"
	case s.Transport == "masque" && s.Params["fake"] != "":
		return "h3"
	case s.Transport == "wg" && s.Params["jc"] != "":
		return "wg"
	}
	return ""
}

// GenerateVariants возвращает до n новых вариантов на основе лучших известных в этой сети:
// QUIC с фейковыми пакетами (h3), HTTP/2 (h2) и WireGuard с «мусорным» прологом (wg).
func GenerateVariants(nk string, mem *Memory, all []Strategy, n int, rnd *rand.Rand, needOK bool) []Strategy {
	parents := map[string][]Strategy{}
	for _, s := range mem.Rank(nk, all) {
		f := family(s)
		if f == "" || len(parents[f]) >= 3 {
			continue
		}
		if needOK && !mem.Worked(nk, s.ID) {
			continue // для пополнения пула берём «родителями» только то, что уже работало
		}
		parents[f] = append(parents[f], s)
	}
	var fams []string
	for _, f := range []string{"h3", "h3", "h2", "wg"} { // QUIC — вдвое чаще остальных
		if len(parents[f]) > 0 {
			fams = append(fams, f)
		}
	}
	if len(fams) == 0 {
		return nil
	}
	eps := map[string][]string{}
	seenEP := map[string]bool{}
	for _, s := range all {
		f := family(s)
		ep := s.Params["endpoint"]
		if f == "" || ep == "" || seenEP[f+ep] || mem.EndpointDead(nk, s.ID) {
			continue // мёртвые адреса в мутации не участвуют
		}
		seenEP[f+ep] = true
		eps[f] = append(eps[f], ep)
	}
	have := map[string]bool{}
	for _, s := range all {
		have[s.ID] = true
	}
	var out []Strategy
	for tries := 0; tries < n*8 && len(out) < n; tries++ {
		f := fams[rnd.Intn(len(fams))]
		ps := parents[f]
		p := ps[rnd.Intn(len(ps))]
		q := map[string]string{}
		for k, v := range p.Params {
			q[k] = v
		}
		if len(eps[f]) > 1 && rnd.Intn(4) == 0 {
			q["endpoint"] = eps[f][rnd.Intn(len(eps[f]))]
		}
		var id string
		switch f {
		case "h3":
			ttl := clampInt(atoiDefault(q["fttl"], 5)+rnd.Intn(5)-2, 2, 12)
			cnt := clampInt(atoiDefault(q["fcount"], 4)+rnd.Intn(5)-2, 1, 10)
			size := atoiDefault(q["fsize"], 1200)
			if rnd.Intn(10) < 3 {
				size = fakeSizePool[rnd.Intn(len(fakeSizePool))]
			}
			if rnd.Intn(10) < 3 {
				q["fake"] = mem.PickGene(nk, "h3.fake", fakeSNIPool, rnd)
			}
			if rnd.Intn(4) == 0 { // настоящий SNI в QUIC Initial — то, что читает DPI
				q["sni"] = mem.PickGene(nk, "h3.sni", sniPool, rnd)
			}
			if rnd.Intn(10) < 3 { // другой порт: операторы нередко режут именно UDP 443
				q["endpoint"] = net.JoinHostPort(hostOnly(q["endpoint"]), mem.PickGene(nk, "h3.port", masquePorts, rnd))
			}
			if rnd.Intn(4) == 0 { // другой период keepalive: помогает против таймеров NAT оператора
				q["keep"] = mem.PickGene(nk, "h3.keep", keepPoolS, rnd)
			}
			if rnd.Intn(3) == 0 { // шумовые пакеты перед рукопожатием (идея из генераторов конфигов)
				q["noise"] = mem.PickGene(nk, "h3.noise", noisePool, rnd)
				q["nmin"], q["nmax"] = "5", "10"
			}
			q["fttl"] = strconv.Itoa(ttl)
			q["fcount"] = strconv.Itoa(cnt)
			q["fsize"] = strconv.Itoa(size)
			id = fmt.Sprintf("h3/%s/g:%s:%s:%dx%ds%d", q["endpoint"], q["sni"], q["fake"], ttl, cnt, size)
			if k := q["keep"]; k != "" {
				id += "k" + k
			}
			if nz := q["noise"]; nz != "" && nz != "0" {
				id += "n" + nz
			}
		case "h2":
			q["sni"] = mem.PickGene(nk, "h2.sni", sniPool, rnd)
			id = fmt.Sprintf("h2/%s/g:%s", q["endpoint"], q["sni"])
		case "wg":
			jc := clampInt(atoiDefault(q["jc"], 4)+rnd.Intn(5)-2, 1, 16)
			jmin := clampInt(atoiDefault(q["jmin"], 40)+rnd.Intn(21)-10, 5, 100)
			jmax := clampInt(atoiDefault(q["jmax"], 70)+rnd.Intn(61)-30, jmin+10, 300)
			q["jc"], q["jmin"], q["jmax"] = strconv.Itoa(jc), strconv.Itoa(jmin), strconv.Itoa(jmax)
			if rnd.Intn(10) < 4 { // у серверов WARP десятки рабочих UDP-портов
				q["endpoint"] = net.JoinHostPort(hostOnly(q["endpoint"]), mem.PickGene(nk, "wg.port", wgPorts, rnd))
			}
			sfx := ""
			if q["rsv"] == "1" {
				sfx = "r"
			}
			id = fmt.Sprintf("wg/%s/g:%d-%d-%d%s", q["endpoint"], jc, jmin, jmax, sfx)
		}
		if id == "" || have[id] {
			continue
		}
		have[id] = true
		out = append(out, Strategy{ID: id, Transport: p.Transport, Params: q})
	}
	return out
}

// learn придумывает и запоминает новые способы для этой сети.
func (e *Engine) learn(nk string) {
	if e.cfg.Mem == nil {
		return
	}
	rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
	gen := GenerateVariants(nk, e.cfg.Mem, e.allStrategies(nk), 6, rnd, false)
	if len(gen) == 0 {
		return
	}
	e.cfg.Mem.AddGenerated(nk, gen)
	Logf("🧬 все известные способы не сработали — придумал %d новых вариантов обхода для сети %s", len(gen), nk)
}

// blame записывает провал стратегии, но только если зарубежный интернет вообще есть: иначе виновата сеть
// (обрыв или режим белых списков), а не стратегия.
func (e *Engine) blame(nk, id string) bool {
	if e.cfg.NetState != nil {
		if st := e.netState(); st != "ok" {
			Logf("   ⚠ зарубежного интернета нет (%s) — стратегию не виню", st)
			return false
		}
	} else if e.cfg.NetAlive != nil && !e.cfg.NetAlive() {
		Logf("   ⚠ интернета нет совсем — стратегию не виню")
		return false
	}
	e.cfg.Mem.Record(nk, id, false, 0)
	return true
}

// waitOnline ждёт, пока зарубежный интернет появится (или станет понятно, что включены белые списки).
// Проверки редеют: 3 с, затем 10 с, затем 30 с.
func (e *Engine) waitOnline(ctx context.Context) {
	iv := 3 * time.Second
	start := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		case <-e.cfg.NetChanged:
		case <-time.After(iv):
		}
		if e.cfg.NetState != nil {
			if st := e.netState(); st == "ok" || st == "whitelist" {
				return
			}
		} else if e.cfg.NetAlive == nil || e.cfg.NetAlive() {
			return
		}
		if since := time.Since(start); since > 10*time.Minute {
			iv = 30 * time.Second
		} else if since > time.Minute {
			iv = 10 * time.Second
		}
	}
}

// grow пополняет пул: придумывает новые варианты на основе стратегий, которые уже работали.
func (e *Engine) grow(nk string) {
	if e.cfg.Mem == nil {
		return
	}
	rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
	gen := GenerateVariants(nk, e.cfg.Mem, e.allStrategies(nk), 6, rnd, true)
	if len(gen) == 0 {
		return
	}
	e.cfg.Mem.AddGenerated(nk, gen)
	Logf("🧬 пополняю пул: придумал %d новых вариантов на основе работающих", len(gen))
}

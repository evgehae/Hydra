package hydra

import (
	"context"
	"net"
	"strings"
	"time"
)

var tgTargets = []struct {
	ip   string
	port uint16
}{
	{"149.154.167.51", 443}, {"149.154.175.50", 443}, {"149.154.167.91", 443}, {"91.108.56.130", 443},
}

const badColoFor = 6 * time.Hour

// coloAllowed: разрешён ли дата-центр настройками и не «плохой» ли он (Telegram не доходит).
func (e *Engine) coloAllowed(nk, colo string) bool {
	if !e.policy().Allows(colo) {
		return false
	}
	if e.soft {
		return true
	}
	return !e.isBadColo(nk, colo)
}

func (e *Engine) isBadColo(nk, colo string) bool {
	e.mu.Lock()
	defer e.mu.Unlock()
	t, ok := e.badColo[nk+"|"+colo]
	return ok && time.Since(t) < badColoFor
}

func (e *Engine) noteBadColo(nk, colo string) {
	e.mu.Lock()
	if e.badColo == nil {
		e.badColo = map[string]time.Time{}
	}
	e.badColo[nk+"|"+colo] = time.Now()
	e.mu.Unlock()
}

func (e *Engine) badColoCount(nk string) int {
	e.mu.Lock()
	defer e.mu.Unlock()
	n := 0
	for k, t := range e.badColo {
		if strings.HasPrefix(k, nk+"|") && time.Since(t) < badColoFor {
			n++
		}
	}
	return n
}

// knownBlocked: по памяти известно, что адрес этой стратегии в этой сети попадает в запрещённый дата-центр.
func (e *Engine) knownBlocked(nk string, s Strategy) bool {
	ep := s.Params["endpoint"]
	if ep == "" {
		return false
	}
	kc := e.cfg.Mem.KnownColo(nk, ep)
	return kc != "" && !e.coloAllowed(nk, kc)
}

// serviceGate проверяет через только что поднятый туннель, доходит ли TCP до Telegram. Если интернет
// работает, а ни один сервер Telegram не отвечает, — дата-центр помечается плохим, и Гидра ищет другой.
// Больше трёх плохих дата-центров в одной сети не набираем: значит, дело не в них.
func (e *Engine) serviceGate(ctx context.Context, nk string, a *attempt, out chan<- string) {
	if e.badColoCount(nk) >= 3 {
		return
	}
	select {
	case <-ctx.Done():
		return
	case <-a.ctx.Done():
		return
	case <-time.After(2500 * time.Millisecond):
	}
	base := false
	for _, ip := range []string{"8.8.8.8", "1.1.1.1"} {
		if _, err := a.dev.tcpProbeTo(a.ctx, net.ParseIP(ip).To4(), 443, 3*time.Second); err == nil {
			base = true
			break
		}
		if a.ctx.Err() != nil {
			return
		}
	}
	if !base {
		return // сеть шатается: вывод был бы ненадёжным
	}
	for _, t := range tgTargets {
		if _, err := a.dev.tcpProbeTo(a.ctx, net.ParseIP(t.ip).To4(), t.port, 3*time.Second); err == nil {
			Logf("✔ Telegram через %s (дата-центр %s) достижим", a.s.ID, a.colo)
			return
		}
		if a.ctx.Err() != nil {
			return
		}
	}
	select {
	case out <- "Telegram не доходит через дата-центр " + a.colo + " (остальной интернет работает) — ищу другой путь":
	default:
	}
}

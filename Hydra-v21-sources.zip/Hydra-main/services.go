package hydra

import (
	"context"
	"fmt"
	"net"
	"strings"
	"time"
)

var serviceTargets = []struct {
	name, ip string
	port     uint16
}{
	{"Telegram DC2", "149.154.167.51", 443},
	{"Telegram DC1/3", "149.154.175.50", 443},
	{"Telegram DC4", "149.154.167.91", 443},
	{"Telegram DC5", "91.108.56.130", 443},
	{"Google", "8.8.8.8", 443},
	{"Cloudflare", "1.1.1.1", 443},
	{"GitHub", "140.82.121.4", 443},
}

// ServiceCheck проверяет через действующий туннель, проходит ли TCP до популярных сервисов
// (SYN-ACK от самого сервиса). Помогает отличить «туннель не пускает» от «сервис режет этот дата-центр».
func (e *Engine) ServiceCheck(ctx context.Context) string {
	d, _ := e.active.Load().(*attemptDev)
	st := e.Status()
	if d == nil || st.State != "up" {
		return "туннель сейчас не подключён: проверять нечего\n"
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Через туннель %s (дата-центр %s):\n", st.Strategy, st.Colo)
	okN := 0
	for _, t := range serviceTargets {
		rtt, err := d.tcpProbeTo(ctx, net.ParseIP(t.ip).To4(), t.port, 3*time.Second)
		if err == nil {
			okN++
			fmt.Fprintf(&b, "  ✔ %s (%s:%d) %d мс\n", t.name, t.ip, t.port, rtt.Milliseconds())
		} else {
			fmt.Fprintf(&b, "  ✘ %s (%s:%d): %v\n", t.name, t.ip, t.port, err)
		}
	}
	fmt.Fprintf(&b, "Доступно %d из %d.\n", okN, len(serviceTargets))
	return b.String()
}
